package com.manpronet.beaconsender;
import androidx.core.content.FileProvider;
public class GenericFileProvider extends FileProvider {}